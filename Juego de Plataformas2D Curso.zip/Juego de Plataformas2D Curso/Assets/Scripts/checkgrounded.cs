﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkgrounded : MonoBehaviour
{
    private playerController player;
    private Rigidbody2D rb2d;
    // Start is called before the first frame update
    void Start()
    {
        player = GetComponentInParent<playerController>();
        rb2d = GetComponentInParent<Rigidbody2D>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "platform")
        {
            rb2d.velocity = new Vector3(0, 0, 0);
            player.transform.parent = collision.transform;
            player.grounded = true;
        }
    }

    private void OnCollisionStay2D(Collision2D col)
    {
        if (col.gameObject.tag == "ground")
        {
            player.grounded = true;
        }
        if (col.gameObject.tag == "platform")
        {
            player.transform.parent = col.transform;
            player.grounded = true;
        }

    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            player.grounded = false;
        }
        if (collision.gameObject.tag == "platform")
        {
            player.transform.parent = null;
            player.grounded = false;
        }
    }

}
