﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Controlador : MonoBehaviour
{
    public playerController Player;
    public CircleCollider2D PlayerCollider;
    public GameObject TextoCentral;
    public int PuntajeWin = 12;
    public Sprite ZeroLife;
    public Image V1;
    public Image V2;
    public Image V3;
    public bool Play=true;
    public Text Score;
    public int Puntaje=0;
    public int Life = 3;

    private Text TextMain;
    // Start is called before the first frame update
    void Start()
    {
        TextMain = TextoCentral.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        ComprobarVidas();
        Scores();
       
        if (!Play)
        {
            TextoCentral.SetActive(true);
            Player.movement = false;
            Player.grounded = false;
            Player.GetComponent<Rigidbody2D>().AddForce(Vector3.zero);
            Player.GetComponent<CircleCollider2D>().isTrigger=true;
            PlayerCollider.isTrigger = true;
        }

        if (Input.GetMouseButton(0) && !Play)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

    }
    void ComprobarVidas()
    {
        switch (Life)
        {
            case 0:
                V1.sprite = ZeroLife;
                Play = false;
                TextMain.text = "Perdiste, Click para Reiniciar";
                break;
            case 1:
                V2.sprite = ZeroLife;
                break;
            case 2:
                V3.sprite = ZeroLife;
                break;
        }
    }
    public void Scores()
    {
        Score.text ="0"+Puntaje;
        if (Puntaje == PuntajeWin)
        {
            Play = false;
        }
    }
}
