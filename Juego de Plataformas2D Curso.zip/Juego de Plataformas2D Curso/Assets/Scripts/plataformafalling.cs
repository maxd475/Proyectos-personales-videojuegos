﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plataformafalling : MonoBehaviour
{
    public float fallDelay =1f;
    public float respawDelay = 5f;

    private Rigidbody2D rb2d;
    private PolygonCollider2D pc2d;
    private Vector3 start;
    // Start is called before the first frame update
    void Start()
    {
        pc2d = GetComponent<PolygonCollider2D>();
        rb2d = GetComponent<Rigidbody2D>();
        start = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Invoke("fall", fallDelay);
            Invoke("respawn", fallDelay + respawDelay);
        }
    }
    void fall()
    {
        rb2d.isKinematic = false;
        pc2d.isTrigger = true;
    }

    void respawn()
    {
        transform.position = start;
        rb2d.isKinematic = true;
        rb2d.velocity = Vector3.zero;
        pc2d.isTrigger = false;
    }
}
